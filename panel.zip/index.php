<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="es">
    <head>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/estilo.css" rel="stylesheet">
    </head><!--/head-->

    <script src="js/jquery.js"></script>
    <div id="content">

        <h3>Paneles de administración</h3>
        <div >
            <button id="dolce" class="btn btn-primary">Il dolce far niente</button>

        </div>


    </div>

    <script type="text/javascript" src="js/inicio.js"></script>


