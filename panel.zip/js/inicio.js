$( "#dolce" ).click(function() {
  window.location.href = "ildolcefarniente/";
});