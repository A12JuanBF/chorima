<?php
session_start();
if (!isset($_SESSION['lang'])) {
    require_once '../include/lenguagl.php';
}
if (isset($_SESSION['lang']) && $_SESSION['lang'] == "es") {
    require_once '../include/lenguaes.php';
}
if (isset($_SESSION['lang']) && $_SESSION['lang'] == "gl") {
    require_once '../include/lenguagl.php';
}
if (isset($_SESSION['lang']) && $_SESSION['lang'] == "en") {
    require_once '../include/lenguaen.php';
}
include '../vista/vista.php';
include '../clases/eventos.php';
include '../clases/carta.php';
$vista = new vista();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Carta | A taberna da chorima</title>
        <!-- for-mobile-apps -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <!--Llamar a vista para las metas genéricas -->
        <?php $vista->getmeta("default"); ?>

        <?php $vista->geticon("default"); ?>

        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
            function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- //for-mobile-apps -->
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />

        <link href="../css/assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <link href="../css/assets/css/font-awesome.css" rel="stylesheet" type="text/css" media="all" />

        <link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
        <!-- js -->
        <script src="../js/jquery-1.11.1.min.js"></script>
        <script src="../js/cookiesmensaje.js"></script>
        <script src="../js/idioma.js"></script>
        <script src="../js/jquery.cookie.js"></script>
        <script src="../js/ampliarimg.js"></script>
        <script type="text/javascript" src="../js/jquery.fancybox.pack.js"></script>
        <!-- //js -->
        <link href='//fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="../css/jquery.fancybox.css" type="text/css" media="screen" />


    </head>

    <body>
        <?php
        $vista->mensajecookies();
        ?>
        <!-- header -->
        <!-- header -->
        <?php
        $vista->cabecera("default");
        ?>
        <!-- //header -->
        <!-- //header -->
        <!-- menu -->
        <div class="menuche">
            <?php
            $vista->getcategoria();
            if (!isset($_GET['cat'])) :
                ?>
                <h4 class='text-center'><?php echo cartaescoger; ?></h4>
                <section id='textocarta'>
                    <img class='img-responsive' src='../images/CHORIMA-SANTIAGO-01.png' title='' alt=''/><p ><?php echo cartap; ?></p>
                    <div class="col-lg-4"><?php $vista->tripadrecomienda(); ?></div>
                    <div class="col-lg-8 hidden-md hidden-sm hidden-xs"><?php $vista->getopiniontripad(); ?></div>
                </section>

            <?php endif; ?>

            <div class="container">
                <?php $vista->getvistaplatos(); ?>


            </div>
        </div>
        <!-- //menu -->
        <!--- footer --->
        <?php
        $vista->pie();
        ?>
        <!--- //footer --->
        <!-- for bootstrap working -->
        <script src="../js/bootstrap.js"></script>
        <!-- //for bootstrap working -->
    </body>
</html>