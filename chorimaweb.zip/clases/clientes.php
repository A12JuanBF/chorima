<?php
require_once 'conexion.php';
/*
 *Gestión subscripción
 */

/**
 * Description of clientes
 *
 * @author JuanDiego
 */
class clientes extends conexion{
    private $local;

    public function __construct($local) {
        parent::__construct();
        $this->local = $local;
    }
    public function comprobarmail($param) {
        
        $sql="select * from clientes where email='".$this->con->real_escape_string($param['email'])."';";
        $this->con->query($sql);
        if ($this->con->affected_rows > 0) {
            return false;
        }
        else{
            return true;
        }
    }
    
    public function setcliente($param) {
        
        $sql="insert into clientes(email,local) values('".$this->con->real_escape_string($param['email'])."','".$this->local."')";
        return $result = $this->con->query($sql);
        
    }
}
