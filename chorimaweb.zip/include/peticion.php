<?php
/* 
 Archivo que controla peticiones ajax
 */
include '../clases/clientes.php';



