<?php

session_start();

$_SESSION['lang']=$_POST['idioma'];

