<?php
include 'clases/eventos.php';
include 'include/meses.php';
$eventos = new eventos("chor");
$arra = json_decode($eventos->geteventos(4));
?>

<div class="container">
    <h3><i class="glyphicon glyphicon-calendar"></i> <?php echo agendacultural; ?></h3>
    <p class="eum"><?php echo eventosinicio; ?></p>
    <?php if (isset($arra)): ?>

    <div class="news-grids">
        <?php foreach (@$arra as $value): ?>
        <?php 
        $arrhora= explode(":", $value->hora);
        $arrfecha= explode("-", $value->fecha);
        $dia=$arrfecha[2];
        $mes=$arrfecha[1];
        $mes=  getmes($mes);
        $hora=$arrhora[0].":".$arrhora[1];
        ?>
        <div class="col-md-6 news-grid eventind">
            <div class="col-xs-4 news-grid-left">

                <p><?php echo $dia; ?> <?php echo $mes ?> <span><?php echo $hora ?></span></p>
                

            </div>
            <div class="col-xs-8 news-grid-right">
                <h4 class="eventonombre"><?php echo $value->nombre; ?></h4>
                <span>Tipo de evento: <?php echo $value->tipo; ?></span> 
                <p>
                    <?php echo $value->descripcion; ?></p>
                <?php if ($value->link !=""): ?>
                <div class="more">
                <a  href="<?php echo $value->link; ?>"><?php echo $value->nombre; ?></a>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="clearfix"> </div>
        </div>
        <?php endforeach; ?>
        <?php else : ?>
        <h2 style="text-align: center;"><?php echo noeventos; ?></h2>
        <?php endif; ?>

        <div class="clearfix"> </div>
        
    </div>

</div>