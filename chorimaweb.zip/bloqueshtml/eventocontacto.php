<div id="contactoeventos" class="col-lg-12 headdings panel panel-default">
    <div class="panel-heading">
    <h2 class="text-center panel-title"><?php echo eventocontactopregunta; ?></h2>
    </div>
    <div class="panel-body">
    <p><?php echo eventocontactoformulario; ?></p>
    <h4 class="text-center"><a class="chorimacolor" href="http://localhost/chorima/contacto/"><i class="glyphicon glyphicon-envelope"></i> <?php echo eventocontactolink; ?></a></h4>
    </div>
</div>