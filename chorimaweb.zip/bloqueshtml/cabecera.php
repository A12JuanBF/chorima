<?php
$directoryURI = $_SERVER['PHP_SELF'];

if ($directoryURI == "/chorima/carta/index.php") {
    $resturante=" ";
    $carta = "active";
    $galeria = " ";
    $contacto = " ";
    $proxeven=" ";
    $anteven=" ";
} 
elseif ($directoryURI == "/chorima/contacto/index.php") {
    $resturante=" ";
    $carta = " ";
    $galeria = " ";
    $contacto = "active";
    $proxeven=" ";
    $anteven=" ";
}
elseif ($directoryURI == "/chorima/galeria/index.php") {
    $resturante=" ";
    $carta = " ";
    $contacto = " ";
    $galeria = "active";
    $proxeven=" ";
    $anteven=" ";
}
elseif ($directoryURI == "/chorima/proximos_eventos/index.php") {
    $resturante=" ";
    $carta = " ";
    $contacto = " ";
    $galeria = " ";
    $proxeven="active";
    $anteven=" ";
}
elseif ($directoryURI == "/chorima/anteriores_eventos/index.php") {
    $resturante=" ";
    $carta = " ";
    $contacto = " ";
    $galeria = " ";
    $proxeven=" ";
    $anteven="active";
}
elseif ($directoryURI == "/chorima/index.php") {
    $resturante="active";
    $carta = " ";
    $contacto = " ";
    $galeria = " ";
    $proxeven=" ";
    $anteven=" ";
}
?>

<div class="header">
		<div class="container">
			<div class="header-nav">
                            <div class="row"><div  class="pull-right"><a  class="idiomas" name="gl" href="#" rel="nofollow">Galego</a><a class="idiomas" name="es" href="#" rel="nofollow">Español</a><a class="idiomas" name="en" href="#" rel="nofollow">English</a></div></div>
				<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display --> 
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
                                        <a class="col-md-12 col-xs-12 col-sm-12 hidden-lg"  href="http://localhost/chorima/"><img class="img-responsive " src="http://localhost/chorima/images/logo.JPG" title="" alt=""/></a>    
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
                                            <a id="logo" class="col-lg-3 " href="http://localhost/chorima/"><img class="img-responsive hidden-md hidden-sm hidden-xs" src="http://localhost/chorima/images/logo.JPG" title="" alt=""/></a>
						<ul class="nav navbar-nav">
							<li class="hvr-bounce-to-bottom <?php echo $resturante; ?>" ><a href="http://localhost/chorima/"><?php echo nav_inicio ?> </a></li>
                                                        <li class="hvr-bounce-to-bottom <?php echo $galeria; ?>"><a href="http://localhost/chorima/galeria/"><?php echo nav_sobrenosotros ?></a></li>
                                                        <li class="hvr-bounce-to-bottom <?php echo $carta; ?>"><a href="http://localhost/chorima/carta/"><?php echo nav_carta ?></a></li>
                                                        <li class="hvr-bounce-to-bottom <?php echo $proxeven; ?>"><a href="http://localhost/chorima/proximos_eventos"><?php echo nav_prox ?></a></li>
                                                        <li class="hvr-bounce-to-bottom <?php echo $anteven; ?>"><a href="http://localhost/chorima/anteriores_eventos"><?php echo nav_ult ?></a></li>
                                                        <li class="hvr-bounce-to-bottom <?php echo $contacto; ?>"><a href="http://localhost/chorima/contacto"><?php echo nav_contacto ?></a></li>
						</ul>
					</div><!-- /navbar-collapse -->
				</nav>
			</div>
		</div>
	</div>
