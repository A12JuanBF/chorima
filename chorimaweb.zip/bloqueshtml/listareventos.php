<?php
$eventos = new eventos("chor");
$arra = json_decode($eventos->geteventos(10));
$pos = 0;
?>
<?php if (isset($arra)): ?>
    <?php foreach (@$arra as $value): ?>
        <?php
        $arrhora = explode(":", $value->hora);
        $arrfecha = explode("-", $value->fecha);
        $dia = $arrfecha[2];
        $mes = $arrfecha[1];
        $mes = getmes($mes);
        $hora = $arrhora[0] . ":" . $arrhora[1];
        ?>
        <?php if ($pos < 1): ?>
            <div class="eventos col-lg-12 panel panel-default">

                <div class="col-lg-3">
                    <div class="row"><img class="img-thumbnail img-responsive" src="../img-eventos/<?php echo $value->imagenperfil; ?>" title="<?php echo $value->nombre; ?>"/></div>
                    <div class="row">
                        <div class=" news-grid-left">
                            <p><?php echo $dia; ?>nd<span><?php echo $mes; ?></span></p>
                        </div>
                    </div>
                    <div class="row"><h3><i class="glyphicon glyphicon-time"></i> <?php echo $hora; ?></h3></div>
                </div>

                <div  class="col-lg-9 headdings">

                    <h1 class="chorimacolor"> <?php echo $value->nombre; ?></h1>
                    <h4>Tipo de evento: <?php echo $value->tipo; ?></h4>
                    <p class="textoevento"><?php echo $value->descripcion; ?></p>
                    <?php if ($value->link != ""): ?>
                        <p class="textoevento" ><a class="linkevento" href="<?php echo $value->link; ?>"><i class="glyphicon glyphicon-new-window"></i> Ver máis sobre <?php echo $value->nombre; ?></a></p>
                    <?php endif; ?>
                </div>
                <div class="col-lg-9 ">
                    <!-- AddToAny BEGIN -->
                    <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                        <a class="a2a_dd" href="https://www.addtoany.com/share"></a>
                        <a class="a2a_button_facebook"></a>
                        <a class="a2a_button_twitter"></a>
                        <a class="a2a_button_google_plus"></a>
                    </div>
                    <script async src="https://static.addtoany.com/menu/page.js"></script>
                    <!-- AddToAny END -->
                </div>

            </div>
            <?php $pos ++; ?>
        <?php else : ?>
            <div class="eventos col-lg-offset-2 col-lg-10 panel panel-default">
                <div class="col-lg-3">

                    <div class="row">
                        <div >
                            <p><b><?php echo $dia; ?> <span><?php echo $mes; ?></span></b></p>
                        </div>
                        
                    </div>
                    <div class="row"><h5><i class="glyphicon glyphicon-time"></i> <?php echo $hora; ?></h5></div>
                    <div><img class="img-thumbnail img-responsive" src="../img-eventos/<?php echo $value->imagenperfil; ?>" title="<?php echo $value->nombre; ?>"/></div>
                </div>
                <div  class="col-lg-9 ">

                    <h3 class="text-left chorimacolor"> <?php echo $value->nombre; ?></h3>
                    <h5>Tipo de evento: <?php echo $value->tipo; ?></h5>
                    <p><?php echo $value->descripcion; ?></p>
                    <?php if ($value->link != ""): ?>
                        <p style="margin-top: 1em;"><a class="linkevento" href="<?php echo $value->link; ?>"><i class="glyphicon glyphicon-new-window"></i> Ver más sobre <?php echo $value->nombre; ?></a></p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

    <?php endforeach; ?>
<?php else : ?>
    <h2 style="text-align: center;"><?php echo noeventos; ?></h2>
<?php endif; ?>