$(document).ready(function() {
        
        $(".fancybox").fancybox({
            openEffect: 'elastic',
            closeEffect: 'elastic',
            helpers: {
                title: {
                    type : 'float',
                    buttons	: {}
                }
            }
        });
    });


